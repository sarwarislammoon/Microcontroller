var annotated =
[
    [ "APSR_Type", "unionAPSR__Type.html", "unionAPSR__Type" ],
    [ "ARM_MPU_Region_t", "structARM__MPU__Region__t.html", "structARM__MPU__Region__t" ],
    [ "CONTROL_Type", "unionCONTROL__Type.html", "unionCONTROL__Type" ],
    [ "CoreDebug_Type", "structCoreDebug__Type.html", "structCoreDebug__Type" ],
    [ "DWT_Type", "structDWT__Type.html", "structDWT__Type" ],
    [ "FPU_Type", "structFPU__Type.html", "structFPU__Type" ],
    [ "ICB_Type", "structICB__Type.html", "structICB__Type" ],
    [ "IPSR_Type", "unionIPSR__Type.html", "unionIPSR__Type" ],
    [ "ITM_Type", "structITM__Type.html", "structITM__Type" ],
    [ "MPU_Type", "structMPU__Type.html", "structMPU__Type" ],
    [ "NVIC_Type", "structNVIC__Type.html", "structNVIC__Type" ],
    [ "PMU_Type", "structPMU__Type.html", "structPMU__Type" ],
    [ "SCB_Type", "structSCB__Type.html", "structSCB__Type" ],
    [ "SCnSCB_Type", "structSCnSCB__Type.html", "structSCnSCB__Type" ],
    [ "SysTick_Type", "structSysTick__Type.html", "structSysTick__Type" ],
    [ "TPI_Type", "structTPI__Type.html", "structTPI__Type" ],
    [ "xPSR_Type", "unionxPSR__Type.html", "unionxPSR__Type" ]
];