function writeFooter()  {
    document.write('Generated on Mon May  2 2022 11:07:00 for CMSIS-Core (Cortex-M) Version 5.6.0 by Arm Ltd. All rights reserved.');
};
