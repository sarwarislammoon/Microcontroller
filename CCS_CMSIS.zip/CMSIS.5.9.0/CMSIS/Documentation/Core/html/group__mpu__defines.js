var group__mpu__defines =
[
    [ "ARM_MPU_ACCESS_xxx", "group__mpu__defines.html#ga71d41084e984be70a23cb640fd89d1e2", null ],
    [ "ARM_MPU_AP_xxx", "group__mpu__defines.html#gabc4788126d7798469cb862a08d3050cc", null ],
    [ "ARM_MPU_CACHEP_xxx", "group__mpu__defines.html#gab23596306119e7831847bd9683de3934", null ],
    [ "ARM_MPU_REGION_SIZE_xxx", "group__mpu__defines.html#gadb0a92c0928c113120567e85ff1ba05c", null ]
];