var group__mve__functions =
[
    [ "SCB_GetMVEType", "group__mve__functions.html#ga9de35f6ff713a3cac7674baf49e22b72", null ]
];