var group__nvic__trustzone__functions =
[
    [ "TZ_NVIC_ClearPendingIRQ_NS", "group__nvic__trustzone__functions.html#ga3b30f8b602b593a806617b671a50731a", null ],
    [ "TZ_NVIC_DisableIRQ_NS", "group__nvic__trustzone__functions.html#gabc58593dea7803c1f1e1ed3b098f497c", null ],
    [ "TZ_NVIC_EnableIRQ_NS", "group__nvic__trustzone__functions.html#gaedea4c16dd4a0b792c7e9d1da4c49295", null ],
    [ "TZ_NVIC_GetActive_NS", "group__nvic__trustzone__functions.html#ga1bffd79bd6365d83281883b6c4b0f218", null ],
    [ "TZ_NVIC_GetEnableIRQ_NS", "group__nvic__trustzone__functions.html#ga57d2a6736704c4a39421ed1a2e7b689b", null ],
    [ "TZ_NVIC_GetPendingIRQ_NS", "group__nvic__trustzone__functions.html#gab85bd0d55d746caf0e414be5284afe24", null ],
    [ "TZ_NVIC_GetPriority_NS", "group__nvic__trustzone__functions.html#gade6a8784339946fdd50575d7e65a3268", null ],
    [ "TZ_NVIC_GetPriorityGrouping_NS", "group__nvic__trustzone__functions.html#gaf5f578628bc8b7154b29577f6f6a87fd", null ],
    [ "TZ_NVIC_SetPendingIRQ_NS", "group__nvic__trustzone__functions.html#gaccbc9aa0eacf4d4c3d3046edb9e02edd", null ],
    [ "TZ_NVIC_SetPriority_NS", "group__nvic__trustzone__functions.html#ga2caf0df3603378c436c838138e42059a", null ],
    [ "TZ_NVIC_SetPriorityGrouping_NS", "group__nvic__trustzone__functions.html#ga0d3b5db0685bd95cc8bd2f7ad0891d39", null ]
];