var group__sau__trustzone__functions =
[
    [ "TZ_SAU_Disable", "group__sau__trustzone__functions.html#ga42e201cea0a4b09f588a28b751f726fb", null ],
    [ "TZ_SAU_Enable", "group__sau__trustzone__functions.html#ga187377409289e34838225ce801fb102c", null ],
    [ "TZ_SAU_Setup", "group__sau__trustzone__functions.html#ga6093bc5939ea8924fbcfdffb8f0553f1", null ]
];