var group__stacksealing__support__trustzone__functions =
[
    [ "__STACK_SEAL", "group__stacksealing__support__trustzone__functions.html#gacc36ddac1642fe80a690364911542d79", null ],
    [ "__TZ_set_STACKSEAL_S", "group__stacksealing__support__trustzone__functions.html#ga87d2473a3adebb73941065366feec690", null ]
];