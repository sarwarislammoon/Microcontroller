var group__systick__trustzone__functions =
[
    [ "TZ_SysTick_Config_NS", "group__systick__trustzone__functions.html#gad18a1b1a6796c652f2b35e728f2e2670", null ]
];