var searchData=
[
  ['evcntr',['EVCNTR',['../structPMU__Type.html#a08f877e8edcb1c19b81ebcf95f85e2f7',1,'PMU_Type']]],
  ['evtyper',['EVTYPER',['../structPMU__Type.html#a27682a8d2fe09d2052a4295d5b4a243b',1,'PMU_Type']]],
  ['exccnt',['EXCCNT',['../structDWT__Type.html#a9fe20c16c5167ca61486caf6832686d1',1,'DWT_Type']]]
];
