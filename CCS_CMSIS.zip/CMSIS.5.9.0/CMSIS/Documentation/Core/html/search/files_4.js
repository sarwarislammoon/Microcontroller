var searchData=
[
  ['template_2etxt',['Template.txt',['../Template_8txt.html',1,'']]]
];
