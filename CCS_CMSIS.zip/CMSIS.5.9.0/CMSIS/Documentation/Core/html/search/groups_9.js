var searchData=
[
  ['trustzone_20for_20armv8_2dm_2fv8_2e1_2dm',['TrustZone for Armv8-M/v8.1-M',['../group__trustzone__functions.html',1,'']]]
];
