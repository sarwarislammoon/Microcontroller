var searchData=
[
  ['scatter_2dloading_20description_20file_20_5c_3cdevice_5c_3e_5fac_3c5_7c6_3e_2esct',['Scatter-Loading description file \&lt;device\&gt;_ac&lt;5|6&gt;.sct',['../linker_sct_pg.html',1,'templates_pg']]],
  ['startup_20file_20startup_5f_5c_3cdevice_5c_3e_2ec',['Startup File startup_\&lt;device\&gt;.c',['../startup_c_pg.html',1,'templates_pg']]],
  ['startup_20file_20startup_5f_5c_3cdevice_5c_3e_2es_20_28deprecated_29',['Startup File startup_\&lt;device\&gt;.s (deprecated)',['../startup_s_pg.html',1,'templates_pg']]],
  ['system_20configuration_20files_20system_5f_3cdevice_3e_2ec_20and_20system_5f_3cdevice_3e_2eh',['System Configuration Files system_&lt;device&gt;.c and system_&lt;device&gt;.h',['../system_c_pg.html',1,'templates_pg']]]
];
