var searchData=
[
  ['trustzone_20setup_3a_20partition_5f_3cdevice_3e_2eh',['TrustZone setup: partition_&lt;device&gt;.h',['../partition_h_pg.html',1,'templates_pg']]]
];
