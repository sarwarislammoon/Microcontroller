var structICB__Type =
[
    [ "ACTLR", "structICB__Type.html#ac43ad74d42fdfff0055b2a62705474f3", null ],
    [ "CPPWR", "structICB__Type.html#ae81003a1446544876fc9c9eccffddab7", null ],
    [ "ICTR", "structICB__Type.html#af468675de58ebcffd888d55cd9c1715d", null ],
    [ "RESERVED0", "structICB__Type.html#a99113d72c2c7e817ffada9ecb3525c16", null ]
];