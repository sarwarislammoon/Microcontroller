var using_pg =
[
    [ "Basic CMSIS Example", "using_CMSIS.html", null ],
    [ "Using Interrupt Vector Remap", "using_VTOR_pg.html", null ],
    [ "Using CMSIS with generic Arm Processors", "using_ARM_pg.html", [
      [ "Create generic Libraries with CMSIS", "using_ARM_pg.html#using_ARM_Lib_sec", null ]
    ] ]
];