function writeFooter()  {
    document.write('Generated on Mon May  2 2022 11:07:01 for CMSIS-Core (Cortex-A) Version 1.2.1 by Arm Ltd. All rights reserved.');
};
